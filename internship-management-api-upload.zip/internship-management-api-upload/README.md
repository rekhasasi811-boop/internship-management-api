# Internship Records REST API — Full Stack Development Task 2

A Node.js + Express REST API that manages internship records with SQLite persistence, input validation, pagination, and complete CRUD operations.

## Requirements
- Node.js 18 or newer
- npm

## Run locally
Open a terminal in this folder and run:

```bash
npm install
npm run seed
npm start
```

The server starts at `http://localhost:3000`. Visit that address to see the API status and endpoint list. SQLite creates `data/internships.db` automatically on first run. Records remain saved when the server restarts.

## Data model
| Field | Type | Required | Notes |
|---|---|---:|---|
| id | integer | automatic | Unique record ID |
| company_name | string | yes | Company name |
| role | string | yes | Internship role |
| location | string | yes | Work location |
| start_date | date string | yes | Internship start date |
| end_date | date string/null | no | Internship end date |
| status | string | no | Applied, Interview, Selected, Rejected, Completed |
| stipend | number | no | Must be zero or greater |
| notes | string | no | Additional details |
| created_at / updated_at | timestamp | automatic | Record timestamps |

## API endpoints
| Method | Endpoint | Description | Success status |
|---|---|---|---:|
| GET | `/api/internships?page=1&limit=10` | List records with pagination | 200 |
| GET | `/api/internships/:id` | Get one record | 200 |
| POST | `/api/internships` | Create a record | 201 |
| PUT | `/api/internships/:id` | Update a record | 200 |
| DELETE | `/api/internships/:id` | Delete a record | 200 |

Pagination defaults to page 1 and 10 records; maximum page size is 100.

## Example request body
Send this JSON to `POST /api/internships` with `Content-Type: application/json`:

```json
{
  "company_name": "Sample Technologies",
  "role": "Full Stack Developer Intern",
  "location": "Remote",
  "start_date": "2026-11-15",
  "end_date": null,
  "status": "Applied",
  "stipend": 5000,
  "notes": "Applying for a software development internship"
}
```

## Response format
Success responses use `{ "success": true, "data": ... }`. Errors use `{ "success": false, "error": { "message": ..., "details": [...] } }` where applicable.

## HTTP status codes
- `200` — successful list, detail, update, or delete
- `201` — record created
- `400` — invalid input, invalid ID, invalid pagination, or malformed JSON
- `404` — record or route not found
- `500` — unexpected server error

## Test with curl
```bash
curl "http://localhost:3000/api/internships?page=1&limit=10"
curl "http://localhost:3000/api/internships/1"
curl -X POST "http://localhost:3000/api/internships" -H "Content-Type: application/json" -d '{"company_name":"Sample Co","role":"Developer Intern","location":"Remote","start_date":"2026-11-15"}'
curl -X PUT "http://localhost:3000/api/internships/1" -H "Content-Type: application/json" -d '{"status":"Interview"}'
curl -X DELETE "http://localhost:3000/api/internships/1"
```

## Project explanation
This project is an Internship Records REST API built using Node.js, Express, and SQLite. It provides create, read, update, and delete operations for internship records. SQLite stores the records persistently. Input validation prevents invalid data, consistent JSON responses communicate success and errors, and pagination makes the records easier to retrieve in smaller pages.

## Files
- `server.js` — Express server and API routes
- `db.js` — SQLite connection and table creation
- `validation.js` — request data validation
- `seed.js` — inserts sample internship records
- `package.json` — dependencies and run scripts
