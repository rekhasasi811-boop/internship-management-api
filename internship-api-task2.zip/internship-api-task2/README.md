# Internship Records REST API — Task 2

A beginner-friendly Node.js + Express REST API with SQLite persistence, input validation, pagination, and CRUD operations.

## 1. Requirements
- Node.js 18 or newer
- npm

## 2. Run the project
Open a terminal in this project folder and run:

```bash
npm install
npm run seed
npm start
```

The API runs at `http://localhost:3000`.

Open `http://localhost:3000` in a browser to check that the server is running.

The SQLite database is created automatically at `data/internships.db`. Data remains saved after the server restarts.

## 3. Data model

| Field | Type | Required | Description |
|---|---|---:|---|
| id | integer | automatic | Unique record ID |
| company_name | string | yes | Company name |
| role | string | yes | Internship role |
| location | string | yes | Work location |
| start_date | date string | yes | Start date |
| end_date | date string/null | no | End date |
| status | string | no | Applied, Interview, Selected, Rejected, Completed |
| stipend | number | no | Stipend; must be 0 or more |
| notes | string | no | Extra information |
| created_at | timestamp | automatic | Created time |
| updated_at | timestamp | automatic | Updated time |

## 4. API endpoints

| Method | Endpoint | Purpose | Success code |
|---|---|---|---:|
| GET | `/api/internships?page=1&limit=10` | List records with pagination | 200 |
| GET | `/api/internships/:id` | Get one record | 200 |
| POST | `/api/internships` | Create a record | 201 |
| PUT | `/api/internships/:id` | Update a record | 200 |
| DELETE | `/api/internships/:id` | Delete a record | 200 |

Pagination defaults to page 1 and 10 records. Maximum limit is 100.

## 5. Test examples (curl)

### List
```bash
curl "http://localhost:3000/api/internships?page=1&limit=10"
```

### Detail
```bash
curl "http://localhost:3000/api/internships/1"
```

### Create
```bash
curl -X POST "http://localhost:3000/api/internships" \
  -H "Content-Type: application/json" \
  -d '{"company_name":"Sample Co","role":"Web Developer Intern","location":"Remote","start_date":"2026-11-15","status":"Applied","stipend":5000,"notes":"Test record"}'
```

### Update
```bash
curl -X PUT "http://localhost:3000/api/internships/1" \
  -H "Content-Type: application/json" \
  -d '{"status":"Interview","stipend":7000}'
```

### Delete
```bash
curl -X DELETE "http://localhost:3000/api/internships/1"
```

## 6. Response format

Successful response:
```json
{
  "success": true,
  "data": {
    "id": 1,
    "company_name": "Edvyro",
    "role": "Full Stack Developer Intern"
  }
}
```

Error response:
```json
{
  "success": false,
  "error": {
    "message": "Validation failed",
    "details": ["company_name is required and must be a non-empty string"]
  }
}
```

## 7. Validation and status codes
- `400` — invalid input, invalid ID, invalid pagination, or malformed JSON
- `404` — record or route not found
- `201` — record created
- `200` — successful read, update, or delete
- `500` — unexpected server error

## 8. Short project explanation

This project is an Internship Records REST API built with Node.js and Express. It supports creating, viewing, updating, and deleting internship records. SQLite stores the records permanently, so they remain available after restarting the server. The API validates user input, returns clear error messages and uses pagination to display records in smaller pages.

## 9. Suggested proof
Publish this project folder in a GitHub repository. Include the source files and this README. Do not upload `node_modules` or the local database file.
