const allowedStatuses = ["Applied", "Interview", "Selected", "Rejected", "Completed"];

function validateInternship(input, partial = false) {
  const errors = [];
  const required = ["company_name", "role", "location", "start_date"];

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return ["Request body must be a JSON object"];
  }

  if (!partial) {
    for (const field of required) {
      if (typeof input[field] !== "string" || !input[field].trim()) {
        errors.push(`${field} is required and must be a non-empty string`);
      }
    }
  } else {
    for (const field of required) {
      if (field in input && (typeof input[field] !== "string" || !input[field].trim())) {
        errors.push(`${field} must be a non-empty string`);
      }
    }
  }

  if ("status" in input && !allowedStatuses.includes(input.status)) {
    errors.push(`status must be one of: ${allowedStatuses.join(", ")}`);
  }
  if ("stipend" in input &&
      (typeof input.stipend !== "number" || !Number.isFinite(input.stipend) || input.stipend < 0)) {
    errors.push("stipend must be a number greater than or equal to 0");
  }
  for (const field of ["start_date", "end_date"]) {
    if (field in input && input[field] !== null &&
        (typeof input[field] !== "string" || Number.isNaN(Date.parse(input[field])))) {
      errors.push(`${field} must be a valid date string (YYYY-MM-DD)`);
    }
  }
  if ("notes" in input && typeof input.notes !== "string") {
    errors.push("notes must be a string");
  }
  return errors;
}

module.exports = { validateInternship };
