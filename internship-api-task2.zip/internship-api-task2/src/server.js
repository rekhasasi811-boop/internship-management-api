const express = require("express");
const db = require("./db");
const { validateInternship } = require("./validation");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

function sendError(res, status, message, details) {
  return res.status(status).json({
    success: false,
    error: { message, ...(details ? { details } : {}) }
  });
}

function toRecord(row) {
  return row || null;
}

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Internship Records API is running",
    endpoints: [
      "GET /api/internships?page=1&limit=10",
      "GET /api/internships/:id",
      "POST /api/internships",
      "PUT /api/internships/:id",
      "DELETE /api/internships/:id"
    ]
  });
});

// List records with pagination
app.get("/api/internships", (req, res) => {
  const page = Number.parseInt(req.query.page || "1", 10);
  const limit = Number.parseInt(req.query.limit || "10", 10);

  if (!Number.isInteger(page) || page < 1 || !Number.isInteger(limit) || limit < 1 || limit > 100) {
    return sendError(res, 400, "page must be >= 1 and limit must be between 1 and 100");
  }

  const total = db.prepare("SELECT COUNT(*) AS count FROM internships").get().count;
  const rows = db.prepare(`
    SELECT * FROM internships ORDER BY id DESC LIMIT ? OFFSET ?
  `).all(limit, (page - 1) * limit);

  res.json({
    success: true,
    data: rows,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    }
  });
});

// Get one record
app.get("/api/internships/:id", (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id < 1) return sendError(res, 400, "Invalid internship ID");

  const record = toRecord(db.prepare("SELECT * FROM internships WHERE id = ?").get(id));
  if (!record) return sendError(res, 404, "Internship record not found");
  res.json({ success: true, data: record });
});

// Create a record
app.post("/api/internships", (req, res) => {
  const errors = validateInternship(req.body);
  if (errors.length) return sendError(res, 400, "Validation failed", errors);

  const body = req.body;
  const result = db.prepare(`
    INSERT INTO internships
      (company_name, role, location, start_date, end_date, status, stipend, notes)
    VALUES
      (@company_name, @role, @location, @start_date, @end_date, @status, @stipend, @notes)
  `).run({
    company_name: body.company_name.trim(),
    role: body.role.trim(),
    location: body.location.trim(),
    start_date: body.start_date,
    end_date: body.end_date || null,
    status: body.status || "Applied",
    stipend: body.stipend ?? 0,
    notes: body.notes || ""
  });

  const record = db.prepare("SELECT * FROM internships WHERE id = ?").get(result.lastInsertRowid);
  res.status(201).json({ success: true, message: "Internship created", data: record });
});

// Update a record (send the fields you want to change)
app.put("/api/internships/:id", (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id < 1) return sendError(res, 400, "Invalid internship ID");

  const existing = db.prepare("SELECT * FROM internships WHERE id = ?").get(id);
  if (!existing) return sendError(res, 404, "Internship record not found");

  const errors = validateInternship(req.body, true);
  if (errors.length) return sendError(res, 400, "Validation failed", errors);

  const allowed = ["company_name", "role", "location", "start_date", "end_date", "status", "stipend", "notes"];
  const merged = { ...existing };
  for (const key of allowed) {
    if (key in req.body) merged[key] = typeof req.body[key] === "string" && ["company_name", "role", "location"].includes(key)
      ? req.body[key].trim() : req.body[key];
  }

  db.prepare(`
    UPDATE internships SET
      company_name = @company_name, role = @role, location = @location,
      start_date = @start_date, end_date = @end_date, status = @status,
      stipend = @stipend, notes = @notes, updated_at = CURRENT_TIMESTAMP
    WHERE id = @id
  `).run({ ...merged, id });

  const updated = db.prepare("SELECT * FROM internships WHERE id = ?").get(id);
  res.json({ success: true, message: "Internship updated", data: updated });
});

// Delete a record
app.delete("/api/internships/:id", (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id < 1) return sendError(res, 400, "Invalid internship ID");

  const result = db.prepare("DELETE FROM internships WHERE id = ?").run(id);
  if (result.changes === 0) return sendError(res, 404, "Internship record not found");
  res.json({ success: true, message: "Internship deleted successfully" });
});

// Unknown routes and malformed JSON
app.use((req, res) => sendError(res, 404, "Route not found"));
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && "body" in err) return sendError(res, 400, "Invalid JSON body");
  console.error(err);
  return sendError(res, 500, "Internal server error");
});

app.listen(PORT, () => {
  console.log(`Internship API running at http://localhost:${PORT}`);
});
