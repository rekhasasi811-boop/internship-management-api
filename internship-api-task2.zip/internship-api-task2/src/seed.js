const db = require("./db");

const records = [
  ["Edvyro", "Full Stack Developer Intern", "Remote", "2026-11-03", "2027-02-03", "Selected", 0, "Fictional sample record"],
  ["Bright Labs", "Backend Developer Intern", "Coimbatore", "2026-11-10", null, "Applied", 5000, "Fictional sample record"],
  ["Nova Tech", "Web Developer Intern", "Chennai", "2026-12-01", "2027-03-01", "Interview", 8000, "Fictional sample record"]
];

const insert = db.prepare(`
  INSERT INTO internships
    (company_name, role, location, start_date, end_date, status, stipend, notes)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`);

const seed = db.transaction(() => {
  if (db.prepare("SELECT COUNT(*) AS count FROM internships").get().count > 0) {
    console.log("Database already has records. Seed skipped.");
    return;
  }
  for (const record of records) insert.run(...record);
  console.log(`${records.length} sample internship records added.`);
});

seed();
